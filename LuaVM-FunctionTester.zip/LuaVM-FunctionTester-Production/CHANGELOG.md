# Changelog

## [Unreleased]
- Production-grade test runner
- Safer JSON encoder
- CI workflow
- Credits added for @slyemane

## [0.1.0] - 2025-10-21
- Initial production release of LuaVM-FunctionTester
